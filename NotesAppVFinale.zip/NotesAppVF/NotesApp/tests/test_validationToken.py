import delorean
from freezegun import freeze_time
from carnetNotes import validation
from .cles import CLE_PRIVEE, CLE_PUBLIC


INVALID_CLE_PUBLIC = '''
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnC0iNyIEDLUj/MBcGDa3
7AH4D+TkHQRuK3gHLV9PciaX4qnDjmEQvK4GA41FQYGLr99d+ol16I1ptaecFomy
jkqGDT9POfgj554ihuh5446uohjiojtj564664mcJFZYfBVc0PrmLClW6lFsI8Zt
Di0VrQUO0zcHuejdT4B3nKhPIsES9elX9fWz7mebH1jeTzYorP+tonTZFTUML2n3
Ken3gjHu5ZLJgSRNyYtGl3DuJ7w9fQ4GTPrYniO+kRV3zvqnyjaYLHoNIQTYxmmW
G/JGBc5Vjp9R6UUU96heELEGQCPa7dtoxxD2KUUs1la8yYfydH8KJ6YzHrb2pPUS
twIDAQAB
-----END PUBLIC KEY-----
'''


def test_encoderDecoder():
    data = {
        'exemple': 'data',
    }

    token = validation.encoderToken(data, CLE_PRIVEE)
    assert data == validation.decoderToken(token, CLE_PUBLIC)


def test_tokenEnteteInvalide_formatInvalide():
    entete = 'Mauvais entête'
    resultat = validation.validerEnteteToken(entete, CLE_PUBLIC)
    assert None is resultat


def test_tokenEnteteInvalide_MauvaisToken():
    entete = 'le Bearer a des valeurs incorrecte.'
    resultat = validation.validerEnteteToken(entete, CLE_PUBLIC)
    assert None is resultat


def test_tokenInvalide_PasDeheader():
    entete = None
    resultat = validation.validerEnteteToken(entete, CLE_PUBLIC)
    assert None is resultat


def test_tokenEnteteInvalid_pasTempsExpiration():
    data = {
        'owner': 'diallo',
    }
    token = validation.encoderToken(data, CLE_PRIVEE)
    token = token.decode('utf8')
    entete = f'Bearer {token}'
    resultat = validation.validerEnteteToken(entete, CLE_PUBLIC)
    assert None is resultat


@freeze_time('2020-11-15 10:22:01')
def test_invalide_token_entete_expire():
    expire = delorean.parse('2020-11-15 10:22:00').datetime
    data = {
        'owner': 'diallo',
        'exp': expire,
    }
    token = validation.encoderToken(data, CLE_PRIVEE)
    token = token.decode('utf8')
    entete = f'Bearer {token}'
    resultat = validation.validerEnteteToken(entete, CLE_PUBLIC)
    assert None is resultat


@freeze_time('2020-05-17 20:10:09')
def test_enteteTokenInvalide_pasDeOwner():
    expire = delorean.parse('2020-05-17 20:10:09').datetime
    data = {
        'exp': expire,
    }
    token = validation.encoderToken(data, CLE_PRIVEE)
    token = token.decode('utf8')
    entete = f'Bearer {token}'
    resultat = validation.validerEnteteToken(entete, CLE_PUBLIC)
    assert None is resultat


def test_enteteTokenValide_cleInvalide():
    entete = validation.genererEnteteToken('diallo', CLE_PRIVEE)
    resultat = validation.validerEnteteToken(entete, INVALID_CLE_PUBLIC)
    assert None is resultat


def test_enteteTokenValide():
    entete = validation.genererEnteteToken('diallo', CLE_PRIVEE)
    resultat = validation.validerEnteteToken(entete, CLE_PUBLIC)
    assert 'diallo' == resultat
