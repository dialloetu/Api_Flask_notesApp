'''
Test des operations sur les notes
'''
from unittest.mock import ANY
import http.client
from freezegun import freeze_time
from .cles import CLE_PRIVEE
from carnetNotes import validation
from faker import Faker
fake = Faker()


@freeze_time('2020-11-07 12:06:34')
def test_creerMesNotes(client):
    new_note = {
        'owner': fake.name(),
        'text': fake.text(120),
    }
    entete = validation.genererEnteteToken(fake.name(), CLE_PRIVEE)
    entete_auth = {
        'Authorization': entete,
    }
    reponse = client.post('/api/mes/notes/', data=new_note,
                           headers=entete_auth)
    resultat = reponse.json

    assert http.client.CREATED == reponse.status_code

    data = {
        'id': ANY,
        'owner': ANY,
        'text': new_note['text'],
        'timestamp': '2020-11-07T12:30:23',
    }
    assert resultat == data


def test_creerMesNotes_nonAuth(client):
    new_note = {
        'username': fake.name(),
        'text': fake.text(120),
    }
    reponse = client.post('/api/mes/notes/', data=new_note)
    assert http.client.UNAUTHORIZED == reponse.status_code


def test_listerMesNotes(client, note_fixture):
    owner = fake.name()
    text = fake.text(120)

    # Creer une nouvelle note
    new_note = {
        'text': text,
    }
    entete = validation.genererEnteteToken(owner, CLE_PRIVEE)
    data_entete = {
        'Authorization': entete,
    }
    reponse = client.post('/api/mes/notes/', data=new_note, headers=data_entete)
    resultat = reponse.json

    assert http.client.CREATED == reponse.status_code

    # Recup les notes d'un utilisateur
    reponse = client.get('/api/mes/notes/', headers=data_entete)
    results = reponse.json

    assert http.client.OK == reponse.status_code
    assert len(results) == 1
    resultat = results[0]
    exp_resultat = {
        'id': ANY,
        'username': owner,
        'text': text,
        'timestamp': ANY,
    }
    assert resultat == exp_resultat


def test_listerMesNotes_nonAuth(client):
    response = client.get('/api/mes/notes/')
    assert http.client.UNAUTHORIZED == response.status_code


def test_list_notes(client, note_fixture):
    reponse = client.get('/api/notes/')
    resultat = reponse.json

    assert http.client.OK == reponse.status_code
    assert len(resultat) > 0

    # Vérifier que les identifiants s'incrementent
    preced_id = -1
    for note in resultat:
        data = {
            'text': ANY,
            'owner': ANY,
            'id': ANY,
            'timestamp': ANY,
        }
        assert data == note
        assert note['id'] > preced_id
        preced_id = note['id']


def test_listerNotesRechercher(client, note_fixture):
    owner = fake.name()
    new_note = {
        'owner': owner,
        'text': 'Aller debogger une application'
    }
    entete = validation.genererEnteteToken(owner,CLE_PRIVEE)
    data_entete = {
        'Authorization': entete,
    }
    reponse = client.post('/api/mes/notes/', data=new_note, headers=data_entete)
    assert http.client.CREATED == reponse.status_code

    reponse = client.get('/api/notes/?search=debogger')
    resultat = reponse.json

    assert http.client.OK == reponse.status_code
    assert len(resultat) > 0

    # Vérifiez que les valeurs renvoyées contiennent "debogger"
    for note in resultat:
        data = {
            'text': ANY,
            'owner': owner,
            'id': ANY,
            'timestamp': ANY,
        }
        assert data == note
        assert 'debogger' in note['text'].lower()


def test_getNote(client, note_fixture):
    note_id = note_fixture[0]
    reponse = client.get(f'/api/notes/{note_id}/')
    resultat = reponse.json

    assert http.client.OK == reponse.status_code
    assert 'text' in resultat
    assert 'owner' in resultat
    assert 'timestamp' in resultat
    assert 'id' in resultat


def test_getNoteInexistante(client, note_fixture):
    note_id = 123456
    reponse = client.get(f'/api/notes/{note_id}/')

    assert http.client.NOT_FOUND == reponse.status_code
