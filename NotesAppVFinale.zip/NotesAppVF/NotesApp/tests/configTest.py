import pytest
import http.client
from carnetNotes.app import create_app
from .cles import CLE_PRIVEE
from carnetNotes import validation
from faker import Faker
fake = Faker()


@pytest.fixture
def app():
    application = create_app()

    application.app_context().push()
    # Initialisation de la base de données
    application.db.create_all()

    return application


@pytest.fixture
def note_fixture(client):
    '''
    Generer l'arboresence des notes.
    '''

    note_ids = []
    for _ in range(3):
        note = {
            'text': fake.text(240),
        }
        header = validation.genererEnteteToken(fake.name(), CLE_PRIVEE)
        headers = {
            'Authorization': header,
        }
        response = client.post('/api/mes/notes/', data=note,
                               headers=headers)
        assert http.client.CREATED == response.status_code
        result = response.json
        note_ids.append(result['id'])

    yield note_ids

    # Supprimez toutes les notes
    response = client.get('/api/notes/')
    notes = response.json
    for note in notes:
        note_id = note['id']
        url = f'/admin/notes/{note_id}/'
        response = client.delete(url)
        assert http.client.NO_CONTENT == response.status_code
