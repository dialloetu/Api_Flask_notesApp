from carnetNotes.app import create_app

if __name__ == '__main__':
    application = create_app()
    application.app_context().push()
    # initialisation de la base de données
    application.db.create_all()
