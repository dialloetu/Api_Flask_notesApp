import http.client
from datetime import datetime
from flask_restplus import Namespace, Resource, fields
from carnetNotes import configurationCles
from carnetNotes.models import NoteModel
from carnetNotes.validation import validerEnteteToken
from carnetNotes.db import db
from flask import abort

api_route = Namespace('api', description='Les opérations de l\'API')


def authentificationParseurEntete(param):
    owner = validerEnteteToken(param, configurationCles.CLE_PUBLIQUE)
    if owner is None:
        abort(401)
    return owner


# Formats d'entrée et de sortie pour la note
auth_parseur = api_route.parser()
auth_parseur.add_argument('Authorization', location='headers', type=str, help='Le bearer Token d\'accès qui est le (JSON Web Token)')

note_parseur = auth_parseur.copy()
note_parseur.add_argument('text', type=str, required=True, help='Contenu de la note.')

model = {
    'id': fields.Integer(),
    'owner': fields.String(),
    'text': fields.String(),
    'timestamp': fields.DateTime(),
}
note_model = api_route.model('Note', model)


@api_route.route('/mes/notes/')
class MesNotes(Resource):

    @api_route.doc('list_notes')
    @api_route.expect(auth_parseur)
    @api_route.marshal_with(note_model, as_list=True)
    def get(self):
        '''
        Réccuperer toutes mes notes de mon carnet de notes
        '''
        args = auth_parseur.parse_args()
        owner = authentificationParseurEntete(args['Authorization'])
        notes = (NoteModel.query.filter(NoteModel.owner == owner).order_by('id').all())
        return notes

    @api_route.doc('creer_note')
    @api_route.expect(note_parseur)
    @api_route.marshal_with(note_model, code=http.client.CREATED)
    def post(self):
        '''
        Créer une nouvelle note dans le carnet de notes
        '''
        args = note_parseur.parse_args()
        owner = authentificationParseurEntete(args['Authorization'])

        new_note = NoteModel(owner=owner, text=args['text'], timestamp=datetime.utcnow())
        db.session.add(new_note)
        db.session.commit()

        resultat = api_route.marshal(new_note, note_model)

        return resultat, http.client.CREATED


parseur = api_route.parser()
parseur.add_argument('search', type=str, required=False, help='Rechercher des notes')


@api_route.route('/notes/')
class ListerNotes(Resource):

    @api_route.doc('list_notes')
    @api_route.marshal_with(note_model, as_list=True)
    @api_route.expect(parseur)
    def get(self):
        '''
        Réccuperer toutes les notes du carnet de notes
        '''
        argument = parseur.parse_args()
        parametreRecherche = argument['search']
        requete = NoteModel.query
        if parametreRecherche:
            requete = (requete.filter(NoteModel.text.contains(parametreRecherche)))

        requete = requete.order_by('id')
        notes = requete.all()

        return notes


@api_route.route('/notes/<int:note_id>/')
class ReccupererNote(Resource):

    @api_route.doc('recuperer_note')
    @api_route.marshal_with(note_model)
    def get(self, note_id):
        '''
        Récuperer une note dans le carnet de notes
        '''
        note = NoteModel.query.get(note_id)
        if not note:
            # La note n'existe pas dans le carnet
            return '', http.client.NOT_FOUND

        return note
