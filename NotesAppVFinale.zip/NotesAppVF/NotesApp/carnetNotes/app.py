from flask import Flask
from flask_restplus import Api


def create_app():
    from carnetNotes.api_router import api_route
    from carnetNotes.admin_router import admin_route

    application = Flask(__name__)
    api = Api(application, version='1.0', title='API de l\'application Carnet de notes',
              description='Une API simple pour le Carnet de Notes (Créer, Rechercher, Supprimer, Mettre à jour)')

    from carnetNotes.db import db, db_config
    application.config['RESTPLUS_MASK_SWAGGER'] = False
    application.config.update(db_config)
    db.init_app(application)
    application.db = db

    api.add_namespace(api_route)
    api.add_namespace(admin_route)

    return application
