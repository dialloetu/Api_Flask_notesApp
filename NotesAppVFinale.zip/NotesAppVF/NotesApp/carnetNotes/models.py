from sqlalchemy import func
from carnetNotes.db import db


class NoteModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner = db.Column(db.String(30))
    text = db.Column(db.String(120))
    timestamp = db.Column(db.DateTime, server_default=func.now())
