import jwt
from parse import parse
from datetime import datetime, timedelta

import logging
log = logging.getLogger(__name__)


def encoderToken(payload, clePrivee):
    return jwt.encode(payload, clePrivee, algorithm='RS256')


def decoderToken(token, clePublique):
    return jwt.decode(token, clePublique, algoritms='RS256')


def genererEnteteToken(nomUtilisateur, clePrivee):
    '''
    Générez un en-tête de token basé sur le nom d'utilisateur. Se connecter à l'aide de la clé privée.
    '''
    payload = {
        'name': nomUtilisateur,
        'iat': datetime.utcnow(),
        'exp': datetime.utcnow() + timedelta(days=2),
    }
    token = encoderToken(payload, clePrivee)
    token = token.decode('utf8')
    return f'Bearer {token}'


def validerEnteteToken(entete, clePublique):
    '''
    Validez qu'un en-tête de token est correct
    Si c'est correct, il renvoie le nom d'utilisateur, sinon, il renvoie Aucun (None)
    '''
    if not entete:
        log.info('pas d\'entête')
        return None

    # Récupérer le Bearer token
    parseur = parse('Bearer {}', entete)
    if not parseur:
        log.info(f'Mauvais format pour l\'en-tête "{entete}"')
        return None
    token = parseur[0]
    try:
        decodeurToken = decoderToken(token.encode('utf8'), clePublique)
    except jwt.exceptions.DecodeError:
        log.warning(f'Erreur de décodage de l\'en-tête "{entete}". Il peut s\'agir d\'une clé incorrecte ou d\'une mauvaise clé.')
        return None
    except jwt.exceptions.ExpiredSignatureError:
        log.error(f'L\'en-tête d\'authentification a expiré.')
        return None

    # Vérifier l'expiration du token
    if 'exp' not in decodeurToken:
        log.warning('Le token n\'a pas expirer.')
        return None

    # Vérifiez que le nom d'utilisateur est dans le token
    if 'name' not in decodeurToken:
        log.warning('Le token n\'a pas le nom d\'utilisateur')
        return None

    log.info('En-tête validé avec succès')
    return decodeurToken['name']
