import http.client
from flask_restplus import Namespace, Resource
from carnetNotes.models import NoteModel
from carnetNotes.db import db

admin_route = Namespace('admin', description='Les operations back. de l\'admin. ')


@admin_route.route('/notes/<int:note_id>/')
class NoteDelete(Resource):

    @admin_route.doc('supprimer_note', responses={http.client.NO_CONTENT: 'Pas de contenu!'})
    def delete(self, note_id):
        '''
        Supprimer une note
        '''
        note = NoteModel.query.get(note_id)
        if not note:
            # La note n'existe pas
            return '', http.client.NO_CONTENT

        db.session.delete(note)
        db.session.commit()

        return '', http.client.NO_CONTENT
